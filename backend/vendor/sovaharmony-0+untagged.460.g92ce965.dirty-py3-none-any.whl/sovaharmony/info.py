info = {
    'Description': "sovaharmony, a harmonization eeg pipeline using the bids standard",
    'Name':'sovaharmony',
    'CodeURL':'https://github.com/GRUNECO/eeg-harmonization',
}
